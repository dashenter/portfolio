"""
JBI010: The Russo-Ukrainian Conflict
Author: Lina Ochoa, Gijs Walravens

Copyright (c) 2022 - Eindhoven University of Technology, The Netherlands
This software is made available under the terms of the MIT License.
"""

import datetime
import pytest
import ipytest
from app.types import Conflict, Event, ViolentEvent, DemonstrationEvent, NonViolentEvent


# // BEGIN_TODO [task_2, task_3, task_4, task_5.a, task_5.b]
# i am sorry, i did not know how or what to do here, too difficult for me :(
# // END_TODO [task_2, task_3, task_4, task_5.a, task_5.b]