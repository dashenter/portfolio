"""
JBI010: The Russo-Ukrainian Conflict
Author: Lina Ochoa, Gijs Walravens

Copyright (c) 2022 - Eindhoven University of Technology, The Netherlands
This software is made available under the terms of the MIT License.
"""

import datetime
import pytest
import app.types as typ


# // BEGIN_TODO [task_2, task_3, task_4, task_5.a, task_5.b]

# TODO =====> Replace this line with your code. <===== ===== #

# // END_TODO [task_2, task_3, task_4, task_5.a, task_5.b]