"""
JBI010: The Russo-Ukrainian Conflict
Author: Gijs Walravens

Copyright (c) 2022 - Eindhoven University of Technology, The Netherlands
This software is made available under the terms of the MIT License.
"""
from datetime import datetime



def translate(value: int, left_min: int, left_max: int, right_min: int, right_max: int) -> float:
    """
    Maps a given *value* that lies within the range *left_min* to *left_max* to
    another range between *right_min* and *right_max*.
    :param value: the value that should be translated to another range
    :param left_min the lower bound of the original value's range
    :param left_max the upper bound of the original value's range
    :param right_min the lower bound of the new range
    :param right_max the upper bound of the new range
    :return: the value translated relatively to the other range.
    """
    # Figure out how 'wide' each range is
    left_span = left_max - left_min
    right_span = right_max - right_min

    # Convert the left range into a 0-1 range (float)
    value_scaled = float(value - left_min) / float(left_span)

    # Convert the 0-1 range into a value in the right range
    return right_min + (value_scaled * right_span)
