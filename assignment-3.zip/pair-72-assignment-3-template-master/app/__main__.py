"""
JBI010: The Russo-Ukrainian Conflict
Author: Gijs Walravens

Copyright (c) 2022 - Eindhoven University of Technology, The Netherlands
This software is made available under the terms of the MIT License.
"""

import dashboard
import app.types as typs

# Press the green button in the gutter to run the script.
if __name__ == '__main__':

    # Run Dashboard? (set to True to run Dash, set to False for console printing)
    # Leave this on false until you are at the Dashboard task!
    dash_mode: bool = True

    if dash_mode:
        # // BEGIN_TODO [task_5.c] Integrating your data with the dashboard

        ukraine_conflict = typs.Conflict('Ukraine Crisis')
        ukraine_conflict.read_dataset('../data/ukraine-crisis.csv')
        for e in ukraine_conflict.events:
            e.compute_impact((0, 10))
        # // END_TODO [task_5.c]

        my_dashboard = dashboard.create_dashboard(ukraine_conflict)

        # Start server
        my_dashboard.run_server(debug=True)
