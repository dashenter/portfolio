"""
JBI010: The Russo-Ukrainian Conflict
Author: Lina Ochoa

Copyright (c) 2022 - Eindhoven University of Technology, The Netherlands
This software is made available under the terms of the MIT License.
"""

import csv
import datetime
import math
import statistics
from typing import Dict, List, Tuple
import re

# // BEGIN_TODO [task_2, task_3, task_4, task_5.a, task_5.b]

class Event:
    '''
    Represents an event.
    '''
    VIOLENT = 1
    DEMONSTRATION = 2
    NON_VIOLENT = 3

    def __init__(self, date, region: str, location: str, latitude: float, longitude: float, general_type: int, type1: str, subtype: str, actors: List[str], fatalities: int) -> None:
        '''
        Initializes the event class.
        :param date: datetime date
        :param region: string of region
        :param location: string of location
        :param latitude: float of the latitude
        :param longitude: float of the longitude
        :param general_type: integer of the type of the event
        :param type1: string of the type of the event
        :param subtype: string of the subtype of the event
        :param actors: list of strings of actors
        :param fatalities: integer of fatalities
        '''
        self.date = date
        self.region = region
        self.location = location
        self.latitude = latitude
        self.longitude = longitude
        self.general_type = general_type
        self.type1 = type1
        self.subtype = subtype
        self.actors = actors
        self.fatalities = fatalities
        self.impact = -1
        if self.general_type == 1:
            self.general_type_name = 'Violent'
        elif self.general_type == 2:
            self.general_type_name = 'Demonstration'
        elif self.general_type == 3:
            self.general_type_name = 'Non-Violent'
        self.impact = -1

    def __str__(self) -> str:
        '''
        :return: string of the event and the date, region, class and fatalities of the event
        '''
        return f'[Event] Date: {self.date} - Region: {self.region} - Class: {self.general_type_name} - Fatalities: {self.fatalities}'

    def compute_impact(self, threshold: Tuple[int, int]) -> None:
        '''
        Computes the impact of an event.
        :param threshold: threshold of the event
        :return: None
        '''
        if threshold[0] >= self.fatalities:
            self.impact = 1
        elif threshold[0] < self.fatalities <= threshold[1]:
            self.impact = 2
        elif any('civilian' in actor.lower() for actor in self.actors):
            self.impact = 3
        else:
            self.impact = 3


class ViolentEvent(Event):
    '''
    Represents a violent event.
    '''
    def __init__(self, date, region: str, location: str, latitude: float, longitude: float, type1: str, subtype: str, actors: List[str], fatalities: int) -> None:
        '''
        Initializes the ViolentEvent object.
        :param date: date of the event
        :param region: region of the event
        :param location: location of the event
        :param latitude: latitude of the event
        :param longitude: longitude of the event
        :param type1: type of the event
        :param subtype: subtype of the event
        :param actors: actors in the event
        :param fatalities: fatalities of the event
        '''
        super().__init__(date, region, location, latitude, longitude, Event.VIOLENT, type1, subtype, actors, fatalities)


class DemonstrationEvent(Event):
    '''
    Represents a demonstration event.
    '''
    def __init__(self, date, region: str, location: str, latitude: float, longitude: float, type1: str, subtype: str, actors: List[str], fatalities: int) -> None:
        '''
        Initializes the DemonstrationEvent object.
        :param date: date of the event
        :param region: region of the event
        :param location: location of the event
        :param latitude: latitude of the event
        :param longitude: longitude of the event
        :param type1: type of the event
        :param subtype: subtype of the event
        :param actors: actors in the event
        :param fatalities: fatalities of the event
        '''
        super().__init__(date, region, location, latitude, longitude, Event.DEMONSTRATION, type1, subtype, actors, fatalities)

    def compute_impact(self, threshold: Tuple[int, int]) -> None:
        '''
        Computes the impact of the event.
        :param threshold: threshold of the event.
        :return: None
        '''
        if self.fatalities <= threshold[1]:
            self.impact = 2
        elif any('civilian' in actor.lower() for actor in self.actors):
            self.impact = 3
        else:
            self.impact = 3


class NonViolentEvent(Event):
    '''
    Represents a non-violent event.
    '''
    def __init__(self, date, region: str, location: str, latitude: float, longitude: float, type1: str, subtype: str, actors: List[str], fatalities: int) -> None:
        '''
        Initializes the DemonstrationEvent object.
        :param date: date of the event
        :param region: region of the event
        :param location: location of the event
        :param latitude: latitude of the event
        :param longitude: longitude of the event
        :param type1: type of the event
        :param subtype: subtype of the event
        :param actors: actors in the event
        :param fatalities: fatalities of the event
        '''
        super().__init__(date, region, location, latitude, longitude, Event.NON_VIOLENT, type1, subtype, actors, fatalities)

    def compute_impact(self, threshold: Tuple[int, int]) -> None:
        '''
        Computes the impact of the event.
        :param threshold: threshold of the event
        :return: None
        '''
        if self.fatalities <= threshold[0]:
            self.impact = 2
        elif any('civilian' in actor.lower() for actor in self.actors):
            self.impact = 3
        else:
            self.impact = 3


class Conflict:
    '''
    Represents a conflict.
    '''

    def __init__(self, name: str) -> None:
        '''
        Initializes a conflict class.
        :param conflict: string of the conflict
        :param name: string of the name
        :param events: list of the events
        '''
        self.name = name
        self.events = []

    def read_dataset(self, path: str) -> None:
        '''
        Reads the dataset row by row.
        :param path: path to the dataset
        :return: None
        '''
        def get_date(a):
            '''
            Converts the date.
            :param a: date string
            :return: date as a datetime element
            '''
            date = datetime.datetime.strptime(a, "%d-%B-%Y")
            return date

        def get_actor(act1: str, act2: str) -> List[str]:
            '''
            Gets the actors within the event.
            :param act1: first actor
            :param act2: second actor
            :return: the list of actors
            '''
            actors = []
            if act1 != '':
                actors.append(act1)
            if act2 != '':
                actors.append(act2)
            return actors

        def which_type(event: str) -> int:
            '''
            Checks what type is the event.
            :param event: a type of event
            :return: returns if the event was violent, demonstration or non-violent
            '''
            if event == 'Battles' or event == 'Explosions/Remote violence' or event == 'Violence against civilians':
                return Event.VIOLENT
            elif event == 'Protests' or event == 'Riots':
                return Event.DEMONSTRATION
            elif event == 'Strategic developments':
                return Event.NON_VIOLENT

        file = open(path)
        csvreader = csv.reader(file)
        next(csvreader)

        for event in csvreader:
            date = get_date(event[1])
            region = event[11]
            location = event[14]
            latitude = float(event[15])
            longitude = float(event[16])
            type1 = event[3]
            subtype = event[4]
            actors = get_actor(event[5], event[8])
            fatalities = int(event[19])

            if which_type(event[3]) == Event.VIOLENT:
                eobject = ViolentEvent(date, region, location, latitude, longitude, type1, subtype, actors, fatalities)
            elif which_type(event[3]) == Event.DEMONSTRATION:
                eobject = DemonstrationEvent(date, region, location, latitude, longitude, type1, subtype, actors, fatalities)
            elif which_type(event[3]) == Event.NON_VIOLENT:
                eobject = NonViolentEvent(date, region, location, latitude, longitude, type1, subtype, actors, fatalities)
            self.events.append(eobject)

    def conflict_to_list(self) -> List[Dict[str, any]]:
        """
        Takes a Conflict object and returns a list of dictionaries
        containing all data.
        :return: a list of dictionaries with all Event data.
        """
        # Create a resulting list
        result = list()

        # Collect data for all the events
        for event in self.events:
            new_dict = dict()
            new_dict["Date"] = event.date
            new_dict["Region"] = event.region
            new_dict["Location"] = event.location
            new_dict["Latitude"] = event.latitude
            new_dict["Longitude"] = event.longitude
            new_dict["General type"] = event.general_type
            new_dict["Type"] = event.type1
            new_dict["Subtype"] = event.subtype
            new_dict["Actors"] = event.actors
            new_dict["Fatalities"] = event.fatalities
            new_dict["Impact"] = event.impact
            # Uncomment if you decide to solve the bonus task 3.6
            # new_dict["Civilian involvement"] = event.civilians_involvement
            result.append(new_dict)
        return result

    def compute_total_fatalities(self) -> float:
        '''
        Computes the total number of fatalities of the conflict.
        :return: the total number of fatalities.
        '''
        fatalities = [e.fatalities for e in self.events]
        return sum(fatalities)

    def compute_median_fatalities(self) -> float:
        '''
        Computes the median of the fatalities.
        :return: the median of the fatalities
        '''
        fatalities = [e.fatalities for e in self.events]
        return statistics.median(fatalities)

    def compute_mean_fatalities(self) -> float:
        '''
        Computes the mean of the fatalities.
        :return: the mean of the fatalities
        '''
        fatalities = [e.fatalities for e in self.events]
        return statistics.mean(fatalities)

    def compute_mode_fatalities(self) -> List[float]:
        '''
        Computes the mode of the fatalities.
        :return: the mode of the fatalities
        '''
        fatalities = [e.fatalities for e in self.events]
        return statistics.multimode(fatalities)

    def compute_stdev_fatalities(self) -> float:
        '''
        Computes the standard deviation of the fatalities.
        :return: the standard deviation of the fatalities.
        '''
        fatalities = [e.fatalities for e in self.events]
        return statistics.stdev(fatalities)

    def compute_iqr_fatalities(self) -> float:
        '''
        Computes the InterQuartile Range of the fatalities.
        :return: the InterQuartile Range deviation of fatalities
        '''
        fatalities = [e.fatalities for e in self.events]
        quantiles = statistics.quantiles(fatalities)
        return quantiles[2] - quantiles[0]

# // END_TODO [task_2, task_3, task_4, task_5.a, task_5.b]
