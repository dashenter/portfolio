"""
JBI010: The Russo-Ukrainian Conflict
Author: Gijs Walravens

Copyright (c) 2022 - Eindhoven University of Technology, The Netherlands
This software is made available under the terms of the MIT License.
"""

import json
from typing import Dict, List
import dash
import dash_leaflet as dl
import dash_leaflet.express as dlx
import app.types as typs
from dash import Dash, Input, Output, html
import dash_bootstrap_components as dbc
from dash_extensions.javascript import Namespace
from app.utils import translate


def create_dashboard(ukraine_conflict: typs.Conflict) -> Dash:
    # Get JS namespace
    ns = Namespace("myNamespace", "mySubNamespace")

    # Create app object
    app = dash.Dash(__name__
                    , assets_folder="../assets"
                    , external_stylesheets=
                    [dbc.themes.SOLAR, dbc.icons.BOOTSTRAP])

    # region Helper functions

    def create_tooltip(e: Dict[str, any]) -> str:
        """
        Creates the HTML structure as string for the hover tooltip of an event.
        :param e: the event for which to create the tooltip
        :return: the HTML structure as a string.
        """
        date = f"<tr><td><b>Date</b></td><td>{e['Date']}</td></tr>"
        region = f"<tr><td><b>Region</b></td><td>{e['Region']}</td></tr>"
        typ = f"<tr><td><b>Type</b></td><td>{e['Type']}</td></tr>"
        subtype = f"<tr><td><b>Subtype</b></td><td>{e['Subtype']}</td></tr>"
        fatalities = f"<tr><td><b>Fatalities</b></td><td>{e['Fatalities']}</td></tr>"

        return f"<table class='table'>{date}{region}{typ}{subtype}{fatalities}</table>"

    def load_geojson(path: str):
        with open(path, encoding="cp866") as file:
            return json.load(file)

    # endregion

    # Create a List of Dicts containing all the event information
    events = ukraine_conflict.conflict_to_list()

    # Get min and max fatalities
    min_fatalities = min(events, key=lambda x: x["Fatalities"])["Fatalities"]
    max_fatalities = max(events, key=lambda x: x["Fatalities"])["Fatalities"]

    # Add tooltips and radius size
    for event in events:
        event["tooltip"] = create_tooltip(event)
        event["radius"] = translate(event["Fatalities"], min_fatalities, max_fatalities, 10, 50)

    # Convert it to geojson
    my_geo = dlx.dicts_to_geojson(events, lon="Longitude", lat="Latitude")

    # Load GeoJSONs for airport and port markers
    airport_geo = load_geojson("../data/Airports.geojson")
    ports_geo = load_geojson("../data/Ports.geojson")

    # region Layout

    app.layout = html.Div([
        dbc.Container([
            dbc.Row([
                # Map card
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody([
                            html.H4("Event map", className="card-title"),
                            # The map
                            dl.Map([dl.TileLayer(),
                                    dl.GeoJSON(data=airport_geo, id="airport_geojson",
                                               options=dict(pointToLayer=ns("drawAirport"), hideout=dict(toggle=True),
                                                            filter=ns("ukraineFilter"))),
                                    dl.GeoJSON(data=ports_geo, id="port_geojson",
                                               options=dict(pointToLayer=ns("drawPort"), hideout=dict(toggle=True),
                                                            filter=ns("ukraineFilter"))),
                                    dl.GeoJSON(data=my_geo, id="conflict_geojson", cluster=True
                                               , superClusterOptions={"radius": 100}
                                               , options=dict(pointToLayer=ns("pointToLayer"))
                                               , hideout=dict(
                                            circleOptions=dict(fillOpacity=0.7, stroke=False, radius=5)))
                                    ], zoom=6, center=(48.500, 31.887), style={'height': '800px'}),
                            html.H5("Filters"),
                            # Checkboxes for filtering
                            dbc.Checklist(
                                options=[
                                    {"label": "Airports", "value": 1},
                                    {"label": "Ports", "value": 2}
                                ], value=[1, 2], id="filter-checklist"
                            )
                        ])
                    ), width=8
                ),
                # Sidebar card
                dbc.Col(
                    dbc.Card(
                        dbc.CardBody([
                            dbc.Table([
                                html.Tbody([
                                    html.Tr(
                                        html.Td(html.B("Russo-Ukrainian War", style={'color': 'black'}),
                                                className="text-center", style={'backgroundColor': '#C3D6EF'})
                                    ),
                                    html.Tr(
                                        html.Td("Part of the post-Soviet conflicts", className="text-center",
                                                style={'color': 'black', 'backgroundColor': '#DCDCDC'})
                                    ),
                                    html.Tr(
                                        html.Td([
                                            html.Img(
                                                src="https://upload.wikimedia.org/wikipedia/commons/4/4f/2022_Russian_invasion_of_Ukraine.svg",
                                                style={'height': '100%', 'width': '100%'}),
                                            html.P("Military situation as of 6 October 2022", className="text-center"),
                                            html.Div([
                                                html.Div(className="box yellow"),
                                                "Controlled by Ukraine"
                                            ], style={"float": "left", "display": "flex"}),
                                            html.Div([
                                                html.Div(className="box red"),
                                                "Controlled by Russia"
                                            ], style={"float": "right", "display": "flex"})
                                        ])
                                    ),
                                    html.Tr([
                                        html.Td([
                                            dbc.Row([
                                                dbc.Col(
                                                    html.B("Date")
                                                ),
                                                dbc.Col(
                                                    "20 February 2014 - present"
                                                )
                                            ]),
                                            dbc.Row([
                                                dbc.Col(
                                                    html.B("Location")
                                                ),
                                                dbc.Col(
                                                    "Ukraine"
                                                )
                                            ]),
                                            dbc.Row([
                                                dbc.Col(
                                                    html.B("Status")
                                                ),
                                                dbc.Col(
                                                    html.I("Ongoing")
                                                )
                                            ])
                                        ])
                                    ]),
                                    html.Tr(
                                        html.Td(html.B("Belligerents", style={'color': 'black'}),
                                                className="text-center",
                                                style={'backgroundColor': '#C3D6EF'})
                                    ),
                                    html.Tr([
                                        html.Td(
                                            html.Div([
                                                html.Img(src="https://flagcdn.com/w80/ua.png", className="flag-icon"),
                                                "Ukraine"], className="image-text"
                                            ), style={"width": "100%"}),
                                        html.Td([
                                            html.Ul([
                                                html.Li(
                                                    html.Div([
                                                        html.Img(src="https://flagcdn.com/w80/ru.png",
                                                                 className="flag-icon"),
                                                        "Russia"], className="image-text"
                                                    )),
                                                html.Li("Donetsk People's Republic"),
                                                html.Li("Luhansk People's Republic")
                                            ], className="no-bullets")
                                        ], style={"width": "100%"})
                                    ], style={"display": "flex"}),
                                    html.Tr(
                                        html.Td(html.B("Leaders", style={'color': 'black'}), className="text-center",
                                                style={'backgroundColor': '#C3D6EF'})
                                    ),
                                    html.Tr([
                                        html.Td(
                                            html.Div([
                                                html.Img(src="https://flagcdn.com/w80/ua.png", className="flag-icon"),
                                                "Volodymyr Zelenskyy"], className="image-text"
                                            ), style={"width": "100%"}),
                                        html.Td([
                                            html.Ul([
                                                html.Li(html.Div([
                                                    html.Img(src="https://flagcdn.com/w80/ru.png",
                                                             className="flag-icon"),
                                                    "Vladimir Putin"], className="image-text"
                                                )),
                                            ], className="no-bullets")
                                        ], style={"width": "100%"})
                                    ], style={"display": "flex"}),
                                    html.Tr(
                                        html.Td(html.B("Statistics", style={'color': 'black'}), className="text-center",
                                                style={'backgroundColor': '#C3D6EF'})
                                    ),
                                    html.Tr([
                                        html.Td([
                                            dbc.Row([
                                                dbc.Col(
                                                    html.B("Total fatalities")
                                                ),
                                                dbc.Col(
                                                    str(ukraine_conflict.compute_total_fatalities())
                                                )
                                            ]),
                                            dbc.Row([
                                                dbc.Col(
                                                    html.B("Mean fatalities")
                                                ),
                                                dbc.Col(
                                                    str(f"{ukraine_conflict.compute_mean_fatalities():.4f}")
                                                )
                                            ]),
                                            dbc.Row([
                                                dbc.Col(
                                                    html.B("Median fatalities")
                                                ),
                                                dbc.Col(
                                                    str(ukraine_conflict.compute_median_fatalities())
                                                )
                                            ]),
                                            dbc.Row([
                                                dbc.Col(
                                                    html.B("Mode fatalities")
                                                ),
                                                dbc.Col(
                                                    str(ukraine_conflict.compute_mode_fatalities())
                                                )
                                            ]),
                                            dbc.Row([
                                                dbc.Col(
                                                    html.B("Standard deviation fatalities")
                                                ),
                                                dbc.Col(
                                                    str(f"{ukraine_conflict.compute_stdev_fatalities():.4f}")
                                                )
                                            ])
                                        ])
                                    ])
                                ])
                            ])
                        ])
                    )
                )
            ])
        ], fluid=True)
    ], style={"margin": "2em"})

    # endregion

    # region Callbacks

    @app.callback(
        Output("airport_geojson", "hideout"),
        Output("port_geojson", "hideout"),
        Input("filter-checklist", "value")
    )
    def on_filter_change(checklist_value):
        airport_toggle = 1 in checklist_value
        port_toggle = 2 in checklist_value

        return dict(toggle=airport_toggle), dict(toggle=port_toggle)

    # endregion

    return app
