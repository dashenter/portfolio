window.myNamespace = Object.assign({}, window.myNamespace, {  
    mySubNamespace: {
        // Drawing the airport icons
        drawAirport: function(feature, latlng, context) {
            if (typeof context.props.hideout === 'undefined') {
                return null
            }
            const {toggle}  = context.props.hideout;
            const airport = L.icon({iconUrl: `https://raw.githubusercontent.com/mapbox/maki/main/icons/airfield.svg`, iconSize: [15, 30]})

            if (toggle) {
                return L.marker(latlng, {icon: airport})
            } else {
                return null
            }

        },
        // Drawing the port icons
        drawPort: function(feature, latlng, context) {
            if (typeof context.props.hideout === 'undefined') {
                return null
            }
            const {toggle}  = context.props.hideout;
            const port = L.icon({iconUrl: `https://raw.githubusercontent.com/mapbox/maki/main/icons/harbor.svg`, iconSize: [15, 30]})

            if (toggle) {
                return L.marker(latlng, {icon: port})
            } else {
                return null
            }
        },
        // Drawing the event circles
        pointToLayer: function(feature, latlng, context) {
            const {circleOptions} = context.props.hideout;
            if (feature.properties.Fatalities === 0) {
                circleOptions.radius = 5
            } else {
                circleOptions.radius = feature.properties.radius;
            }
            switch(feature.properties.Impact) {
                case 1:
                    circleOptions.fillColor = 'green';
                    break;
                case 2:
                    circleOptions.fillColor = 'orange';
                    break;
                case 3:
                    circleOptions.fillColor = 'red';
                    break;
                default:
                    circleOptions.fillColor = 'black';
            }

            return L.circleMarker(latlng, circleOptions);
        },

        clusterToLayer: function(feature, latlng, index, context) {
            const {min, max, colorscale, circleOptions, colorProp} = context.props.hideout;
            const csc = chroma.scale(colorscale).domain([min, max]);
            // Set color based on mean value of leaves.
            const leaves = index.getLeaves(feature.properties.cluster_id);
            let valueSum = 0;
            for (let i = 0; i < leaves.length; ++i) {
                valueSum += leaves[i].properties[colorProp]
            }
            const valueMean = valueSum / leaves.length;
            // Render a circle with the number of leaves written in the center.
            const icon = L.divIcon.scatter({
                html: '<div style="background-color:white;"><span>' + feature.properties.point_count_abbreviated + '</span></div>',
                className: "marker-cluster",
                iconSize: L.point(40, 40),
                color: csc(valueMean)
            });
            return L.marker(latlng, {icon : icon})
        },
        // Filtering markers only close/in Ukraine
        ukraineFilter: function(feature, context) {
            if (feature.geometry.coordinates[1] > 44 && feature.geometry.coordinates[1] < 52 && feature.geometry.coordinates[0] > 22 && feature.geometry.coordinates[0] < 40) {
                return true
            }
        }
    }  
});