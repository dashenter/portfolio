"""
JBI010: Assignment 2
Authors: Gijs Walravens

Copyright (c) 2022 - Eindhoven University of Technology, The Netherlands
This software is made available under the terms of the MIT License.
"""

import plotly.express as px
from typing import List, Dict
from data_loader import read_dataset
import statistics
#import matplotlib.pyplot as plt
#import pandas as pd


def explore(data: List[Dict[str, any]]) -> None:
    """
    Performs EDA on the passed data.
    :param data: the data that will be used in the EDA
    """
    # Parameters used during EDA
    start_date = "2008-06-01"  # The first date from which to lookup items
    end_date = "2022-06-01"  # The second date from which to lookup items
    amount_of_items = 20  # The amount of items to lookup

    # Return the top items from the defined start date and end date
    top_items_2008 = find_top_items_on_date(data, start_date, amount_of_items)
    top_items_2022 = find_top_items_on_date(data, end_date, amount_of_items)

    # Print those top items
    print(f"Top {amount_of_items} most expensive items on {start_date}:")
    print_items(top_items_2008)
    print(f"Top {amount_of_items} most expensive items on {end_date}:")
    print_items(top_items_2022)

    # TODO [task_3.b]
    """
    (Bonus) You may have noticed that some of the top prices have something 
    in common. Give a (computer science) related reason as to why some of these 
    top valued items look so similar.
    ANSWER: 
    """

    # Compute the mean of those item prices
    mean_2008 = compute_mean(top_items_2008)
    mean_2022 = compute_mean(top_items_2022)
    print(f"The mean price of top items in 2008 is {mean_2008}")
    print(f"The mean price of top items in 2022 is {mean_2022}")

    # Compute the median of those item prices
    median_2008 = compute_median(top_items_2008)
    median_2022 = compute_median(top_items_2022)
    print(f"The median price of top items in 2008 is {median_2008}")
    print(f"The median price of top items in 2022 is {median_2022}")

    # Drawing the box plots
    draw_box_plot(data, top_items_2008)
    draw_box_plot(data, top_items_2022)

    # TODO [task_3.g]
    """
    (Bonus) Based off the differences in mean, median and box plots between the data 
    from 2008 and 2022, what potential real life economic phenomenon do you see 
    happening in the economy of RuneScape? (hint: it is a hot topic in a lot of 
    real life news currently as well)
    ANSWER: 
    """


def find_top_items_on_date(data: List[Dict[str, any]], date: str, amount: int) \
        -> List[Dict[str, any]]:
    """
    Retrieves the top valued items for a given date.
    :param data: list of dicts containing all item data
    :param date: the date to retrieve the top items for
    :param amount: the amount of items to retrieve
    :return: a list of dicts where each dict contains an item name, price pair.
    """

    # // BEGIN_TODO [task_3.a] Finding the top items in a year

    newdata = []
    for j in data:
        if j['Date'][:10] == date:
            newdata.append({'Name': j['Name'], 'Price': j['Price']})
    sortdata = sorted(newdata, key=lambda d: d["Price"], reverse=True)
    return (sortdata[:(amount)])
    # // END_TODO [task_3.a]

def print_items(items: List[Dict[str, any]]) \
        -> None:
    """
    Function to help neatly print a list of items.
    :param items: the item names and their prices
    """
    if items is None:
        print("Passed list is undefined, not printing anything.")
        return
    for i in range(0, len(items)):
        print(f"[{i + 1}] {items[i]['Name']}: {items[i]['Price']}")
    print("")


def compute_mean(items: List[Dict[str, any]]) -> float:
    """
    Computes the mean price of the given items.
    :param items: list of items with their prices to compute the mean for
    :return: the mean price of the given items.
    """

    # // BEGIN_TODO [task_3.c] Computing the mean
    return(float(sum(items)/len(items)))

    # // END_TODO [task_3.c]

def compute_median(items: List[Dict[str, any]]) -> float:
    """
    Computes the median price of the given items.
    :param items: list of items with their prices to compute the mean for
    :return: the median price of the given items.
    """

    # // BEGIN_TODO [task_3.d] Computing the median
    i = len(items)
    items.sort()

    if i % 2 == 0:
        median = (items[i//2] + items[i//2 - 1])/2
    else:
        median = items[i//2]
    return(float(median))

    # // END_TODO [task_3.d]


def draw_box_plot(items: List[Dict[str, any]]
                  , item_subset: List[Dict[str, any]]) -> None:
    """
    Draws box plots for the given item subset.
    :param items: the list of dicts containing all the item data
    :param item_subset: a selection of items (containing at least their names)
    """

    # // BEGIN_TODO [task_3.f] Drawing a box plot
    names = [n['Name'] for n in item_subset]
    name_price = [{'Name': j['Name'], 'Price': j['Price']} for j in items if j['Name'] in names]
    fig = px.box(name_price, x='Name', y='Price')
    fig.show()

    # // END_TODO [task_3.f]
