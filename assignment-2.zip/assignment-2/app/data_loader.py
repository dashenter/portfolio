"""
JBI010: Assignment 2
Authors: Gijs Walravens

Copyright (c) 2022 - Eindhoven University of Technology, The Netherlands
This software is made available under the terms of the MIT License.
"""

import csv
from typing import List, Dict

# // BEGIN_TODO [task_2] Loading and preparing the dataset

def read_dataset(data_path: str) -> List[Dict[str, any]]:
    """
    Reads in the *subject* data from the file, cleans it up and returns it as a
    list of dicts.
    :param data_path: the path to the CSV file
    :return: list of dicts of the prepared data.
    """
    file = open(data_path)
    reader = csv.reader(file)
    list_of_dicts = []
    dicts = {}
    next(reader)
    for j in reader:
        nameid = j[0].strip()
        price = j[1].strip().strip('>')
        date = j[2]
        name = j[3]
        nameurl = j[4]
        dicts = {'Name_ID': int(str(nameid)), 'Price': int(price), 'Date': date, 'Name': name, 'Name_URL': nameurl}
        list_of_dicts.append(dicts)
    return list_of_dicts

data_path = '../data/GE_data.csv'

# // END_TODO [task_2]


