import pandas as pd
import pytest
from typing import List, Dict
from app import data_loader
from app import eda

# // BEGIN_TODO [task_3.e] PyTests for mean and median

def test_compute_mean():
    expected = 9
    actual = compute_mean([6, 10, 10, 10])
    assert expected == actual

def test_compute_median():
    expected = 10
    actual = compute_median([9, 10, 10])
    assert expected == actual

# // END_TODO [task_3.e]
